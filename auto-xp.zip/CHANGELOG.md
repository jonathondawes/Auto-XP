# Changelog

## [1.0.1] - 2024-05-08
### Added
- Initial release
- Automatic XP calculation after combat
- XP distribution among player characters
- Rounding up of XP values
- Chat notifications for XP gains 
- Updated correct URL for install
